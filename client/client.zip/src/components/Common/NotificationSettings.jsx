import React, { useState, useEffect } from 'react';
import { FiBell, FiBellOff, FiCheckCircle, FiAlertCircle, FiRefreshCw } from 'react-icons/fi';
import toast from 'react-hot-toast';
import notificationService from '../../services/notificationService';

function NotificationSettings() {
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [permissionStatus, setPermissionStatus] = useState('default');

  useEffect(() => {
    checkNotificationStatus();
  }, []);

  const checkNotificationStatus = async () => {
    setLoading(true);
    try {
      await notificationService.init();
      const subscription = await notificationService.getSubscription();
      setIsSubscribed(!!subscription);
      setPermissionStatus(Notification.permission);
      setNotificationsEnabled(Notification.permission === 'granted');
    } catch (error) {
      console.error('Error checking notification status:', error);
    } finally {
      setLoading(false);
    }
  };

  const enableNotifications = async () => {
    setLoading(true);
    try {
      const success = await notificationService.init();
      if (success) {
        const subscription = await notificationService.subscribe();
        if (subscription) {
          setIsSubscribed(true);
          setNotificationsEnabled(true);
          setPermissionStatus('granted');
          toast.success('Notifications enabled!');
          notificationService.showLocalNotification('Notifications Enabled', {
            body: 'You will now receive order updates and alerts.',
            tag: 'welcome'
          });
        }
      } else {
        toast.error('Please allow notification permissions');
      }
    } catch (error) {
      console.error('Error enabling notifications:', error);
      toast.error('Failed to enable notifications');
    } finally {
      setLoading(false);
    }
  };

  const disableNotifications = async () => {
    setLoading(true);
    try {
      await notificationService.unsubscribe();
      setIsSubscribed(false);
      setNotificationsEnabled(false);
      toast.success('Notifications disabled');
    } catch (error) {
      console.error('Error disabling notifications:', error);
      toast.error('Failed to disable notifications');
    } finally {
      setLoading(false);
    }
  };

  const testNotification = async () => {
    setLoading(true);
    try {
      await notificationService.testNotification();
      toast.success('Test notification sent!');
    } catch (error) {
      console.error('Error sending test notification:', error);
      toast.error('Failed to send test notification');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      background: '#1E1C2D',
      borderRadius: '12px',
      padding: '16px',
      border: '1px solid #2D2A3F'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
        <div style={{
          width: '40px',
          height: '40px',
          background: notificationsEnabled ? 'rgba(2, 134, 74, 0.1)' : 'rgba(232, 8, 62, 0.1)',
          borderRadius: '10px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}>
          {notificationsEnabled ? (
            <FiBell size={20} color="#02864A" />
          ) : (
            <FiBellOff size={20} color="#E8083E" />
          )}
        </div>
        <div>
          <h3 style={{ fontSize: '14px', margin: 0, color: '#FFFFFF' }}>Push Notifications</h3>
          <p style={{ fontSize: '10px', color: '#A0A0B8', margin: '4px 0 0' }}>
            Receive real-time updates for new orders, cancellations, and alerts
          </p>
        </div>
      </div>

      <div style={{ marginBottom: '16px' }}>
        <div style={{
          padding: '10px',
          background: '#2D2A3F',
          borderRadius: '8px',
          marginBottom: '10px'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: '11px', color: '#FFFFFF' }}>Status:</span>
            <span style={{
              fontSize: '10px',
              color: notificationsEnabled ? '#02864A' : '#E8083E',
              display: 'flex',
              alignItems: 'center',
              gap: '4px'
            }}>
              {notificationsEnabled ? (
                <><FiCheckCircle size={10} /> Enabled</>
              ) : (
                <><FiAlertCircle size={10} /> Disabled</>
              )}
            </span>
          </div>
          {permissionStatus === 'denied' && (
            <div style={{
              marginTop: '8px',
              padding: '6px',
              background: 'rgba(232, 8, 62, 0.1)',
              borderRadius: '6px',
              fontSize: '9px',
              color: '#E8083E'
            }}>
              ⚠️ Notifications are blocked. Please enable them in your browser settings.
            </div>
          )}
        </div>

        <div style={{ display: 'flex', gap: '10px' }}>
          {!notificationsEnabled && permissionStatus !== 'denied' && (
            <button
              onClick={enableNotifications}
              disabled={loading}
              style={{
                flex: 1,
                padding: '8px',
                background: '#02864A',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                cursor: loading ? 'not-allowed' : 'pointer',
                fontSize: '11px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '6px'
              }}
            >
              {loading ? <FiRefreshCw className="spinning" size={12} /> : <FiBell size={12} />}
              {loading ? 'Enabling...' : 'Enable Notifications'}
            </button>
          )}

          {notificationsEnabled && (
            <button
              onClick={disableNotifications}
              disabled={loading}
              style={{
                flex: 1,
                padding: '8px',
                background: '#E8083E',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                cursor: loading ? 'not-allowed' : 'pointer',
                fontSize: '11px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '6px'
              }}
            >
              {loading ? <FiRefreshCw className="spinning" size={12} /> : <FiBellOff size={12} />}
              {loading ? 'Disabling...' : 'Disable Notifications'}
            </button>
          )}

          {notificationsEnabled && (
            <button
              onClick={testNotification}
              disabled={loading}
              style={{
                padding: '8px 12px',
                background: '#573CFA',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                cursor: 'pointer',
                fontSize: '11px',
                display: 'flex',
                alignItems: 'center',
                gap: '6px'
              }}
            >
              <FiBell size={12} /> Test
            </button>
          )}
        </div>
      </div>

      <div style={{
        padding: '8px',
        background: 'rgba(87, 60, 250, 0.1)',
        borderRadius: '6px',
        fontSize: '9px',
        color: '#A0A0B8'
      }}>
        <strong>What you'll receive:</strong>
        <ul style={{ margin: '6px 0 0 16px', padding: 0 }}>
          <li>🔔 New order alerts</li>
          <li>✅ Order acceptance confirmations</li>
          <li>💰 Ready for billing notifications</li>
          <li>❌ Cancellation requests</li>
          <li>⚡ Instant order requests</li>
        </ul>
      </div>

      <style>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .spinning {
          animation: spin 1s linear infinite;
        }
      `}</style>
    </div>
  );
}

export default NotificationSettings;