// src/services/notificationService.js

class NotificationService {
  constructor() {
    this.swRegistration = null;
    this.permissionGranted = false;
    this.isSubscribed = false;
    this.apiUrl = process.env.REACT_APP_API_URL || 'http://localhost:3001/api';
    this.currentUser = null;
    this.vapidPublicKey = process.env.REACT_APP_VAPID_PUBLIC_KEY || 'BLiNlzBDszn00bfL0w25zye0nz725AzWDHT-9RM-pksxzBbMWiO9W8cVTZdL1W5ouLIAcTMKyFkN4eXq4vAb_Kg';
  }

  async init() {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      console.log('❌ Push notifications not supported');
      return false;
    }

    try {
      this.swRegistration = await navigator.serviceWorker.ready;
      console.log('✅ Service Worker ready');
      
      this.permissionGranted = Notification.permission === 'granted';
      console.log('📢 Notification permission:', this.permissionGranted ? 'Granted' : Notification.permission);
      
      return true;
    } catch (error) {
      console.error('❌ Notification init error:', error);
      return false;
    }
  }

  async requestPermission() {
    if (Notification.permission === 'granted') {
      this.permissionGranted = true;
      return true;
    }
    
    if (Notification.permission !== 'denied') {
      const permission = await Notification.requestPermission();
      this.permissionGranted = permission === 'granted';
      console.log('📢 Permission request result:', permission);
      return this.permissionGranted;
    }
    
    console.log('❌ Notification permission denied by user');
    return false;
  }

  async checkSubscription() {
    if (!this.swRegistration) return false;
    
    try {
      const subscription = await this.swRegistration.pushManager.getSubscription();
      this.isSubscribed = !!subscription;
      console.log('📢 Current subscription status:', this.isSubscribed);
      return this.isSubscribed;
    } catch (error) {
      console.error('Error checking subscription:', error);
      return false;
    }
  }

  async subscribe() {
    if (!this.swRegistration) {
      console.log('❌ Service Worker not ready');
      return null;
    }

    if (!this.permissionGranted) {
      console.log('❌ Notification permission not granted');
      const permissionGranted = await this.requestPermission();
      if (!permissionGranted) return null;
    }

    try {
      // Check if already subscribed
      const existingSubscription = await this.swRegistration.pushManager.getSubscription();
      if (existingSubscription) {
        console.log('✅ Already subscribed to push notifications');
        this.isSubscribed = true;
        return existingSubscription;
      }

      console.log('📝 Creating new push subscription...');
      const subscription = await this.swRegistration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: this.urlBase64ToUint8Array(this.vapidPublicKey)
      });
      
      console.log('✅ Push subscription created successfully');
      this.isSubscribed = true;
      
      // Save to server
      await this.saveSubscriptionToServer(subscription);
      return subscription;
    } catch (error) {
      console.error('❌ Failed to subscribe:', error);
      return null;
    }
  }

  async saveSubscriptionToServer(subscription) {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        console.log('❌ No auth token, cannot save subscription');
        return false;
      }

      const response = await fetch(`${this.apiUrl}/notifications/subscribe`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(subscription)
      });
      
      if (!response.ok) {
        const error = await response.json();
        console.error('❌ Server error:', error);
        return false;
      }
      
      const data = await response.json();
      console.log('✅ Subscription saved to server, kitchen subscribers:', data.kitchenSubscribers);
      return true;
    } catch (error) {
      console.error('❌ Error saving subscription:', error);
      return false;
    }
  }

  async unsubscribe() {
    if (!this.swRegistration) return;

    try {
      const subscription = await this.swRegistration.pushManager.getSubscription();
      if (subscription) {
        await subscription.unsubscribe();
        this.isSubscribed = false;
        
        const token = localStorage.getItem('token');
        if (token) {
          await fetch(`${this.apiUrl}/notifications/unsubscribe`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`
            }
          });
        }
        console.log('✅ Unsubscribed successfully');
      }
    } catch (error) {
      console.error('❌ Failed to unsubscribe:', error);
    }
  }

  async ensureSubscription() {
    console.log('🔔 Ensuring push notification subscription...');
    
    // Initialize
    await this.init();
    
    // Check permission and request if needed
    if (!this.permissionGranted) {
      console.log('📢 Requesting notification permission...');
      const granted = await this.requestPermission();
      if (!granted) {
        console.log('❌ User denied notification permission');
        return false;
      }
    }
    
    // Check existing subscription
    const hasSubscription = await this.checkSubscription();
    
    if (!hasSubscription) {
      console.log('📝 No subscription found, creating new one...');
      const subscription = await this.subscribe();
      if (subscription) {
        console.log('✅ Successfully subscribed to push notifications');
        
        // Show success message
        this.showLocalNotification('🔔 Notifications Enabled', {
          body: 'You will now receive real-time order updates!',
          icon: '/icon-192.png',
          tag: 'subscription-success'
        });
        
        return true;
      }
      return false;
    }
    
    console.log('✅ Already subscribed to push notifications');
    return true;
  }

  showLocalNotification(title, options = {}) {
    if (!this.permissionGranted) return;
    
    if (this.swRegistration && this.swRegistration.showNotification) {
      this.swRegistration.showNotification(title, options);
    } else if (Notification.permission === 'granted') {
      new Notification(title, options);
    }
  }

  urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  }
}

export default new NotificationService();